#define FIRST 1
#define SECOND 2

enum {
	ONE = 1,
	TWO = 2
};

#define M_FIRST 1
#define M_SECOND 2

enum {
	M_ONE = 1,
	M_TWO = 2
};

class A {
public:

 #define FIRST 1
 #define SECOND 2

 enum {
	 ONE = 1,
	 TWO = 2
 };
};


