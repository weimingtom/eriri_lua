# Defaults for tolua++ initscript
# sourced by /etc/init.d/tolua++
# installed at /etc/default/tolua++ by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
