/*
** Lua binding: SDL
** Generated automatically by tolua++-1.0.92 on 07/25/07 17:04:29.
*/

/* Exported function */
TOLUA_API int tolua_SDL_open (lua_State* tolua_S);

